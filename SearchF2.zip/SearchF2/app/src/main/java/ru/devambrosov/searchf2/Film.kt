package ru.devambrosov.searchf2

data class Film(val title: String, val poster: Int, val description: String)

